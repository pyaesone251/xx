from odoo import models, fields, api
from odoo.exceptions import ValidationError


class Releaving(models.Model):
    _name = 'hr.releaving'
    _description = 'Releaving Form'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Releaving Number')
    employee_id = fields.Many2one('hr.employee', string="Employee Name", required=True)
    position = fields.Many2one('hr.job', related='employee_id.job_id', store=True)
    manager_id = fields.Many2one('hr.employee', string="Department Manager",
                                 related='employee_id.parent_id', store=True)
    department = fields.Many2one(related='employee_id.department_id', store=True)

    date_submission = fields.Date(
        string="Date of Submission",
        default=fields.Date.context_today
    )

    ot_start_time = fields.Datetime(string="OT Start Time")
    ot_end_time = fields.Datetime(string="OT End Time")
    reason = fields.Text(string="Reason")

    remaining_ot_hours = fields.Float(
        compute="_compute_ot_hours",
        store=True
    )
    total_ot_hours = fields.Float(
        compute="_compute_ot_hours",
        store=True
    )

    employee_total_ot_hours = fields.Float(
        string="Employee Total OT Hours",
        compute="_compute_employee_total_ot",
        store=True
    )

    claim_ids = fields.One2many(
        'hr.releaving.claim',
        'releaving_id',
        string='Releaving Claims'
    )

    hr_approval = fields.Selection(
        [('pending', 'Pending'),
         ('approved', 'Approved'),
         ('rejected', 'Rejected')],
        string="Approval by HR",
        default='pending',
        tracking=True
    )

    hod_approval = fields.Selection(
        [('pending', 'Pending'),
         ('approved', 'Approved'),
         ('rejected', 'Rejected')],
        string="Approval by Manager",
        default='pending',
        tracking=True
    )

    @api.depends('ot_start_time', 'ot_end_time', 'claim_ids.rlv_hours')
    def _compute_ot_hours(self):
        for rec in self:
            base_ot = 0.0
            if rec.ot_start_time and rec.ot_end_time:
                delta = rec.ot_end_time - rec.ot_start_time
                base_ot = delta.total_seconds() / 3600

            used_rlv = sum(rec.claim_ids.mapped('rlv_hours'))

            rec.total_ot_hours = base_ot
            rec.remaining_ot_hours = base_ot - used_rlv

    @api.constrains('rlv_hours')
def _check_rlv_hours(self):
    for rec in self:
        if rec.rlv_hours > rec.releaving_id.employee_total_ot_hours:
            raise ValidationError(
                "RLV hours cannot exceed employee total remaining OT!"
            )





class ReleavingClaim(models.Model):
    _name = 'hr.releaving.claim'
    _description = 'Releaving Claim'

    releaving_id = fields.Many2one('hr.releaving',string="Releaving Reference",required=True)
    employee_id = fields.Many2one(related='releaving_id.employee_id',store=True,string="Employee Name")
    position = fields.Many2one(related='employee_id.job_id',store=True)
    manager_id = fields.Many2one('hr.employee',string="Deperment Manager",related='employee_id.parent_id',store=True)
    department = fields.Many2one(related='employee_id.department_id',store=True)
    rlv_datetime = fields.Datetime(string="Releaving Date & Time")
    rlv_start_time = fields.Datetime(string="RLV Start Time")
    rlv_end_time = fields.Datetime(string="RLV End Time")
    ot_claim_date = fields.Date(string="OT Claim Date",default=fields.Date.today)
    ot_hours = fields.Float(string="OT Hours",compute='_compute_ot_hours',store=True)

    rlv_hours = fields.Float(string="RLV Used Hours",compute="_compute_rlv_hours",store=True)
    remaining_ot_hours = fields.Float(string="Remaining OT Hours",related='releaving_id.remaining_ot_hours',store=True,readonly=True)


    @api.depends('rlv_start_time', 'rlv_end_time')
    def _compute_rlv_hours(self):
        for rec in self:
            if rec.rlv_start_time and rec.rlv_end_time:
                delta = rec.rlv_end_time - rec.rlv_start_time
                rec.rlv_hours = delta.total_seconds() / 3600
            else:
                rec.rlv_hours = 0.0

    @api.depends('releaving_id.ot_start_time', 'releaving_id.ot_end_time')
    def _compute_ot_hours(self):
        for rec in self:
            start = rec.releaving_id.ot_start_time
            end = rec.releaving_id.ot_end_time
            if start and end:
                delta = end - start
                rec.ot_hours = delta.total_seconds() / 3600
            else:
                rec.ot_hours = 0.0

    @api.constrains('rlv_hours')
    def _check_rlv_hours(self):
        for rec in self:
            if rec.rlv_hours > rec.releaving_id.remaining_ot_hours:
                raise ValidationError("RLV hours cannot exceed remaining OT hours!")

    # Approval Actions
    def action_hr_approve(self):
        for rec in self:
            rec.releaving_id.hr_approval = 'approved'

    def action_hod_approve(self):
        for rec in self:
            rec.releaving_id.hod_approval = 'approved'


    






