# -*- coding: utf-8 -*-
# from odoo import http


# class GitForm(http.Controller):
#     @http.route('/git__form/git__form', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/git__form/git__form/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('git__form.listing', {
#             'root': '/git__form/git__form',
#             'objects': http.request.env['git__form.git__form'].search([]),
#         })

#     @http.route('/git__form/git__form/objects/<model("git__form.git__form"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('git__form.object', {
#             'object': obj
#         })

